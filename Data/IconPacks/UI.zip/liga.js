/* A polyfill for browsers that don't support ligatures. */
/* The script tag referring to this file must be placed before the ending body tag. */

/* To provide support for elements dynamically added, this script adds
   method 'icomoonLiga' to the window object. You can pass element references to this method.
*/
(function () {
    'use strict';
    function supportsProperty(p) {
        var prefixes = ['Webkit', 'Moz', 'O', 'ms'],
            i,
            div = document.createElement('div'),
            ret = p in div.style;
        if (!ret) {
            p = p.charAt(0).toUpperCase() + p.substr(1);
            for (i = 0; i < prefixes.length; i += 1) {
                ret = prefixes[i] + p in div.style;
                if (ret) {
                    break;
                }
            }
        }
        return ret;
    }
    var icons;
    if (!supportsProperty('fontFeatureSettings')) {
        icons = {
            'clock': '&#xe903;',
            'time2': '&#xe903;',
            'search': '&#xe906;',
            'magnifier': '&#xe906;',
            'key': '&#xe91a;',
            'password': '&#xe91a;',
            'cog': '&#xe907;',
            'gear': '&#xe907;',
            'eye': '&#xe91b;',
            'views': '&#xe91b;',
            'eye-blocked': '&#xe91c;',
            'views4': '&#xe91c;',
            'star-full': '&#xe917;',
            'rate3': '&#xe917;',
            'plus': '&#xe908;',
            'add': '&#xe908;',
            'minus': '&#xe909;',
            'subtract': '&#xe909;',
            'cross': '&#xe90a;',
            'cancel': '&#xe90a;',
            'checkmark': '&#xe90b;',
            'tick': '&#xe90b;',
            'radio-checked': '&#xe90c;',
            'radio-button': '&#xe90c;',
          '0': 0
        };
        delete icons['0'];
        window.icomoonLiga = function (els) {
            var classes,
                el,
                i,
                innerHTML,
                key;
            els = els || document.getElementsByTagName('*');
            if (!els.length) {
                els = [els];
            }
            for (i = 0; ; i += 1) {
                el = els[i];
                if (!el) {
                    break;
                }
                classes = el.className;
                if (/ico/.test(classes)) {
                    innerHTML = el.innerHTML;
                    if (innerHTML && innerHTML.length > 1) {
                        for (key in icons) {
                            if (icons.hasOwnProperty(key)) {
                                innerHTML = innerHTML.replace(new RegExp(key, 'g'), icons[key]);
                            }
                        }
                        el.innerHTML = innerHTML;
                    }
                }
            }
        };
        window.icomoonLiga();
    }
}());
